﻿using UnityEngine;
using System.Collections;

public class ShipMover : MonoBehaviour {
	[SerializeField]private GameObject _cube;
    [SerializeField] private GameObject _cylinder;
    [SerializeField]private float _speed = 3.0f;
	private Vector3 _startPos;
	private Vector3 _endPos;
    private Vector3 _tempPos;


	private void Update () {
        Vector3 dir = (_endPos - _cube.transform.position).normalized;
        Quaternion look = Quaternion.LookRotation(dir);
        _cube.transform.rotation = look;
        // The main goal here is to avoid the red cylinder in the middle of the scene!
        // DO NOT use Unity's physics or navigation meshes.

        _cube.transform.position = _cube.transform.position + dir * Time.deltaTime * _speed;
        _tempPos = _cube.transform.position;
        if (Vector3.Distance(_cylinder.transform.position, _cube.transform.position) < 3.5f)
        {
            if (_tempPos.z > 0)
            {
                _tempPos.z += 0.1f;
            }
            else
            {
                _tempPos.z -= 0.1f;
            }
            _cube.transform.position = _tempPos;
        }


            // if cube is close to end point, reset
            if (Vector3.Distance(_endPos, _cube.transform.position) <= (dir * Time.deltaTime * _speed).magnitude) {
			ResetCube();
		}
	}

	private void ResetCube() {
		_startPos = new Vector3(4.5f, 0.0f, Random.Range(-4.5f, 4.5f));
		_endPos = _startPos;
		_endPos.x *= -1.0f;
		_endPos.z = Random.Range(-4.5f, 4.5f);
		_cube.transform.position = _startPos;
	}

	private void Start () {
		ResetCube();
	}
}
