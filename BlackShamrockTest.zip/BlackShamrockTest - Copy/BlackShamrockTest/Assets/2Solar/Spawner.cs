﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour {
    public GameObject[] astroids;
    public Vector3 spawnValues;

    int randAstroid;
    public int maxAstroids = 50;
    public int astroidsSpawned = 0;
    public bool stop;

	// Use this for initialization
	void Start () {
        StartCoroutine(spawnWait());
	}
	
	// Update is called once per frame
	void Update () {
		if(maxAstroids <= astroidsSpawned)
        {
            stop = true;
        }
        else
        {
            stop = false;
        }
	}





    IEnumerator spawnWait()
    {
        yield return new WaitForSeconds(1);
        while(!stop)
        {
            randAstroid = Random.Range(0, 4);
            Vector3 spawnPosition = GetSpawnPosition();
                

        
           if (spawnPosition != Vector3.zero)
                {
                Instantiate(astroids[randAstroid], spawnPosition + transform.TransformPoint(0, 0, 0), gameObject.transform.rotation);
                astroidsSpawned += 1;
            }
          
            yield return new WaitForSeconds(0);
        }

    }

    Vector3 GetSpawnPosition()
    {
        Vector3 spawnPosition = new Vector3();

        bool test = false;
        while (test == false)
        {
            Vector3 spawnPositionRaw = new Vector3(Random.Range(-spawnValues.x, spawnValues.x), Random.Range(-spawnValues.y, spawnValues.y), 0);
            spawnPosition = new Vector3(spawnPositionRaw.x, spawnPositionRaw.y, 0);
            test = !Physics.CheckSphere(spawnPosition, 0.75f);
        }
        return spawnPosition;
    }
}
